package com.kellia.webtechass.dao;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import java.io.File;
import java.io.IOException;

public class FileUploadUtil {
    private static final String UPLOAD_DIR = "uploads";
    static HttpServletRequest request;HttpServletResponse response;

    public static String saveDoc(String partname) throws ServletException, IOException {
        Part filePart = request.getPart(partname);
        String fileName = filePart.getSubmittedFileName();

        // Create uploads folder if it doesn't exist
        File uploadDir = new File(UPLOAD_DIR);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }

        // Get real path to uploads folder
        String realPath = request.getServletContext().getRealPath(UPLOAD_DIR);

        // Write the file to uploads folder
        filePart.write(realPath + File.separator + fileName);

        return fileName;
    }
}
