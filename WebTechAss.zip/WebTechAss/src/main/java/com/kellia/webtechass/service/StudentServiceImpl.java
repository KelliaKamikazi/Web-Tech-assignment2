package com.kellia.webtechass.service;

import com.kellia.webtechass.dao.StudentDao;
import com.kellia.webtechass.model.Student;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

public class StudentServiceImpl extends UnicastRemoteObject implements StudentService {
    StudentDao studentDao = new StudentDao();
    public StudentServiceImpl() throws RemoteException {
    }

    @Override
    public void createStudent(Student student) {
        studentDao.createStudent(student);
    }

    @Override
    public Student retrieveStudent(String email) {
        return studentDao.getStudentByEmail(email);
    }

    @Override
    public List<Student> retrieveAllSubmissions() {
        return studentDao.getAllSubmissions();
    }
}
