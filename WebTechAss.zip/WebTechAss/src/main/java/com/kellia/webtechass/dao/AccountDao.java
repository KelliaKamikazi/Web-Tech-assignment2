package com.kellia.webtechass.dao;

import com.kellia.webtechass.model.Account;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class AccountDao {
    public boolean createAccount(Account account) {
        //session //transaction //save //commit //close session
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(account);
        tx.commit();
        session.close();
        return Boolean.TRUE;
    }

    public Account getAccountByEmail(String email, String password) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM Account WHERE email = :var_email and password = :var_password";
            Query<Account> query = session.createQuery(hql, Account.class);
            query.setParameter("var_email", email);
            query.setParameter("var_password", password);
            return query.uniqueResult();
        } catch (Exception ex){
            return null;
        }
        finally {
            session.close();
        }
    }
}
