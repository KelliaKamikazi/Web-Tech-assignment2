package com.kellia.webtechass.service;

import com.kellia.webtechass.model.Account;

public interface AccountService {
    public void createAccount(Account account);
    public Account loginAccount(String email, String password);
}
