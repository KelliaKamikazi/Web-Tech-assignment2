package com.kellia.webtechass.dao;

import com.kellia.webtechass.model.Student;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

public class StudentDao {
    public boolean createStudent(Student student) {
        //session //transaction //save //commit //close session
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(student);
        tx.commit();
        session.close();
        return Boolean.TRUE;
    }

    public List<Student> getAllSubmissions() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM Student";
            Query<Student> query = session.createQuery(hql, Student.class);
            return query.list();
        } finally {
            session.close();
        }
    }

    public Student getStudentByEmail(String email) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM Student WHERE email = :var_email";
            Query<Student> query = session.createQuery(hql, Student.class);
            query.setParameter("var_email", email);
            return query.uniqueResult();
        } catch (Exception ex){
            return null;
        }
        finally {
            session.close();
        }
    }
}
