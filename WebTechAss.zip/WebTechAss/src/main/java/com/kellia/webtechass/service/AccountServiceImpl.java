package com.kellia.webtechass.service;

import com.kellia.webtechass.dao.AccountDao;
import com.kellia.webtechass.model.Account;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class AccountServiceImpl extends UnicastRemoteObject implements AccountService {
    AccountDao accountDao = new AccountDao();

    public AccountServiceImpl() throws RemoteException {
    }

    @Override
    public void createAccount(Account account) {
        accountDao.createAccount(account);
    }

    @Override
    public Account loginAccount(String email, String password) {
        return accountDao.getAccountByEmail(email, password);
    }
}
