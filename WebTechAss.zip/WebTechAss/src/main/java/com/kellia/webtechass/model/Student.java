package com.kellia.webtechass.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;
    private String firstName;
    private String secondName;
    private String email;
    private String age;
    private String address;
    private String station;
    private String parentName;
    private String passPhoto;
    private String diploma;

    public Student() {
    }

    public Student(Long id, String firstName, String secondName, String email, String age, String address, String station, String parentName, String passPhoto, String diploma) {
        Id = id;
        this.firstName = firstName;
        this.secondName = secondName;
        this.email = email;
        this.age = age;
        this.address = address;
        this.station = station;
        this.parentName = parentName;
        this.passPhoto = passPhoto;
        this.diploma = diploma;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getStation() {
        return station;
    }

    public void setStation(String station) {
        this.station = station;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public String getPassPhoto() {
        return passPhoto;
    }

    public void setPassPhoto(String passPhoto) {
        this.passPhoto = passPhoto;
    }

    public String getDiploma() {
        return diploma;
    }

    public void setDiploma(String diploma) {
        this.diploma = diploma;
    }
}
