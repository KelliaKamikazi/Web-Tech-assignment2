package com.kellia.webtechass.service;

import com.kellia.webtechass.model.Student;

import java.util.List;

public interface StudentService {
    public void createStudent(Student student);
    public Student retrieveStudent(String email);
    public List<Student> retrieveAllSubmissions();
}
